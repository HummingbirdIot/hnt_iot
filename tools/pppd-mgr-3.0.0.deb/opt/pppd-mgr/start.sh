#! /bin/bash

MODEM_POWER_EN_PIN=23
HW_VERSION_FILE="/etc/hw_version"

hw_detect()
{
    version="1.0"
    if [ -f $HW_VERSION_FILE ]; then
        version=`cat $HW_VERSION_FILE | awk '{printf"%s",$1}'`
    fi
    echo -n $version
}

WAIT_GPIO() {
    sleep 0.2
}

init() {
    # setup GPIOs
    if [ ! -d /sys/class/gpio/gpio$MODEM_POWER_EN_PIN ]
    then
        echo "$MODEM_POWER_EN_PIN" > /sys/class/gpio/export; WAIT_GPIO
    fi

    # set GPIOs as output
    echo "out" > /sys/class/gpio/gpio$MODEM_POWER_EN_PIN/direction; WAIT_GPIO
}

reset() {
    echo "modem power enable through GPIO$MODEM_POWER_EN_PIN..."

    # write output for SX1302 CoreCell power_enable and reset
    hw_version=`hw_detect`
    if [ "$hw_version" = "1.0" ]; then
        # low: enable, high: disable
        echo "1" > /sys/class/gpio/gpio$MODEM_POWER_EN_PIN/value; WAIT_GPIO
        echo "0" > /sys/class/gpio/gpio$MODEM_POWER_EN_PIN/value; WAIT_GPIO
    else
        # low: disable, high: enable
        echo "0" > /sys/class/gpio/gpio$MODEM_POWER_EN_PIN/value; WAIT_GPIO
        echo "1" > /sys/class/gpio/gpio$MODEM_POWER_EN_PIN/value; WAIT_GPIO
    fi
}


killall -9 pppd
init
reset
./pppd_mgr -d -a /dev/modem_ppp -p /dev/modem_ppp -f ./pppdmgr-config.json
